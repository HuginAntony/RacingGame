'use client';

import { useRef, useEffect } from 'react';
import { Player } from '@/types/game';
import styles from './Scoreboard.module.css';

interface ScoreboardProps {
  players: Record<string, Player>;
  currentPlayerId?: string;
  /** Pass `true` during the question phase to show who has answered */
  showAnswered?: boolean;
}

export function Scoreboard({ players, currentPlayerId, showAnswered }: ScoreboardProps) {
  const sorted = Object.values(players).sort((a, b) => b.score - a.score);
  const prevScores = useRef<Record<string, number>>({});

  useEffect(() => {
    for (const p of sorted) {
      prevScores.current[p.id] = p.score;
    }
  });

  return (
    <div className={styles.board}>
      <h3 className={styles.title}>Scores</h3>
      <ul className={styles.list}>
        {sorted.map((player, idx) => {
          const prev = prevScores.current[player.id] ?? player.score;
          const gained = player.score - prev;
          const pulsing = gained > 0;
          return (
            <li
              key={player.id}
              className={`${styles.row} ${player.id === currentPlayerId ? styles.me : ''}`}
              style={{ animationDelay: `${idx * 0.05}s` }}
            >
              <span className={styles.rank}>#{idx + 1}</span>
              <span className={styles.name}>{player.nickname}</span>
              {showAnswered && (
                player.answeredIndex !== null
                  ? <span className={styles.answeredDot} title="Answered" />
                  : <span className={styles.waitingDot} title="Thinking…" />
              )}
              <span className={`${styles.score} ${pulsing ? styles.scorePulse : ''}`}>
                {player.score.toLocaleString()}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
