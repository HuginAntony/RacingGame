import { Question } from '@/types/game';

interface OtdbQuestion {
  category: string;
  type: string;
  difficulty: string;
  question: string;
  correct_answer: string;
  incorrect_answers: string[];
}

interface OtdbResponse {
  response_code: number;
  results: OtdbQuestion[];
}

/** Decode HTML entities returned by Open Trivia DB (no library needed). */
export function decodeEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&lrm;/g, '')
    .replace(/&rlm;/g, '')
    .replace(/&hellip;/g, '…')
    .replace(/&ldquo;/g, '"')
    .replace(/&rdquo;/g, '"')
    .replace(/&lsquo;/g, '\u2018')
    .replace(/&rsquo;/g, '\u2019');
}

/** Shuffle an array in-place using Fisher-Yates and return it. */
function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Fetch 10 random general-knowledge questions from Open Trivia Database.
 * Returns them as Question[] (answers shuffled, correctIndex tracked).
 */
export async function fetchQuestions(amount = 10): Promise<Question[]> {
  const url = `https://opentdb.com/api.php?amount=${amount}&type=multiple`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`OpenTDB request failed: ${res.status}`);
  const data: OtdbResponse = await res.json();
  if (data.response_code !== 0) throw new Error('OpenTDB returned no results');

  return data.results.map((q) => {
    const correct = decodeEntities(q.correct_answer);
    const incorrects = q.incorrect_answers.map(decodeEntities);
    const all = shuffle([correct, ...incorrects]);
    const correctIndex = all.indexOf(correct);
    return {
      category: decodeEntities(q.category),
      question: decodeEntities(q.question),
      answers: all,
      correctIndex,
    };
  });
}
